package edu.fra.uas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArztBewertungssystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArztBewertungssystemApplication.class, args);
	}

}
